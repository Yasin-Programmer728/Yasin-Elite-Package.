import pygame
import subprocess
import sys

# تشغيل بايجيم
pygame.init()

# إعدادات الشاشة
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Yasin Tech - Multi-Project Launcher")

# الألوان
BLACK = (20, 20, 20)
WHITE = (255, 255, 255)
GOLD = (255, 215, 0)
BLUE = (0, 102, 204)
GREEN = (0, 200, 0)

font_title = pygame.font.SysFont("Arial", 50, bold=True)
font_btn = pygame.font.SysFont("Arial", 30, bold=True)

def draw_button(text, rect, color):
    pygame.draw.rect(screen, color, rect, border_radius=12)
    text_surf = font_btn.render(text, True, WHITE)
    screen.blit(text_surf, (rect.x + (rect.width - text_surf.get_width()) // 2, rect.y + 15))

# أماكن الزراير
btn_radar = pygame.Rect(250, 200, 300, 60)
btn_game = pygame.Rect(250, 300, 300, 60)
btn_master = pygame.Rect(250, 400, 300, 60)

running = True
while running:
    screen.fill(BLACK)
    
    # العناوين
    title = font_title.render("YASIN SOFTWARE HUB", True, GOLD)
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 50))
    
    subtitle = font_btn.render("Choose a project to launch:", True, WHITE)
    screen.blit(subtitle, (WIDTH // 2 - subtitle.get_width() // 2, 130))

    # رسم الزراير
    draw_button("1. Advanced Radar", btn_radar, GREEN)
    draw_button("2. Yasin Fire Game", btn_game, BLUE)
    draw_button("3. Master Achievement", btn_master, (150, 0, 150))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        if event.type == pygame.MOUSEBUTTONDOWN:
            # لو داس على الرادار
            if btn_radar.collidepoint(event.pos):
                print("Launching Radar...")
                subprocess.Popen([sys.executable, "import pygame.py"])
            
            # لو داس على اللعبة
            if btn_game.collidepoint(event.pos):
                print("Launching Game...")
                subprocess.Popen([sys.executable, "Yasin_Fire_Pro.py"])
                
            # لو داس على مشروع الإنجاز
            if btn_master.collidepoint(event.pos):
                print("Launching Master Project...")
                subprocess.Popen([sys.executable, "Yasin_Master_Project.py"])

    pygame.display.flip()

pygame.quit()
