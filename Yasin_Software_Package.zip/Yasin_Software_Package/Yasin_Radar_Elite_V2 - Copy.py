import pygame
WHITE = (255, 255, 255)
import pygame
import math
import sys

# تشغيل بايجيم
pygame.init()

# إعدادات الشاشة
WIDTH, HEIGHT = 1100, 700
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Yasin Tech - PRO Radar System v2.0")

# الألوان (تم إضافة WHITE عشان ميعملش Error)
BLACK = (10, 10, 10)
GREEN = (0, 255, 0)
DARK_GREEN = (0, 50, 0)
RED = (255, 0, 0)
WHITE = (255, 255, 255)

clock = pygame.time.Clock()
angle = 0
targets = [] 

font = pygame.font.SysFont("Courier New", 25, bold=True)
title_font = pygame.font.SysFont("Courier New", 45, bold=True)

def draw_radar():
    global angle
    center = (WIDTH // 2, HEIGHT // 2 + 50)
    radius = 300
    
    for r in range(1, 5):
        pygame.draw.circle(screen, DARK_GREEN, center, (radius // 4) * r, 2)
    
    pygame.draw.line(screen, DARK_GREEN, (center[0] - radius, center[1]), (center[0] + radius, center[1]), 1)
    pygame.draw.line(screen, DARK_GREEN, (center[0], center[1] - radius), (center[0], center[1] + radius), 1)

    x = center[0] + radius * math.cos(math.radians(angle))
    y = center[1] + radius * math.sin(math.radians(angle))
    
    pygame.draw.line(screen, GREEN, center, (x, y), 4)

    for target in targets:
        pygame.draw.circle(screen, RED, target, 10)
        
        # حساب الزاوية بين المركز والنقطة الحمراء
        target_angle = math.degrees(math.atan2(target[1] - center[1], target[0] - center[0])) % 360
        
        # لو خط الرادار خبط في النقطة
        if abs(angle - target_angle) < 3:
            pygame.draw.circle(screen, WHITE, target, 15, 2)
            # بيعمل صوت "بيب" بسيط من سماعات الجهاز
            pygame.display.update()
            print("\a") # ده أمر بيطلع صوت تنبيه (Beep) في ويندوز

running = True
while running:
    screen.fill(BLACK)
    
    title_en = title_font.render("SCANNING TERRITORY...", True, GREEN)
    title_ar = font.render("نظام الرادار المتطور - المبرمج ياسين", True, GREEN)
    
    screen.blit(title_en, (WIDTH // 2 - 250, 20))
    screen.blit(title_ar, (WIDTH // 2 - 180, 80))

    draw_radar()
    
    angle += 2
    if angle >= 360:
        angle = 0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            targets.append(event.pos)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
