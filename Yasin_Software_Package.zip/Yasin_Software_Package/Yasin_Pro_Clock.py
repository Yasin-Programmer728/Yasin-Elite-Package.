import pygame
import time
import sys

# تشغيل بايجيم
pygame.init()

# إعداد الشاشة (كبيرة وعريضة 1100x600)
WIDTH, HEIGHT = 1100, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Yasin The Programmer - الساعة العالمية")

# الألوان
BLACK = (10, 10, 10)
CYAN = (0, 255, 255)
WHITE = (244, 244, 244)
GOLD = (255, 215, 0)
GREEN = (0, 255, 0)

# الخطوط
font_time = pygame.font.SysFont("Consolas", 150, bold=True)
font_dev = pygame.font.SysFont("Arial", 45, bold=True)
font_chinese = pygame.font.SysFont("SimSun", 50)

running = True
while running:
    screen.fill(BLACK)
    
    # 1. الحصول على الوقت بنظام 12 ساعة (%I بتخليها من 1 لـ 12)
    # %p بتعرفنا هي AM (صباحاً) ولا PM (مساءً)
    current_time = time.strftime("%I:%M:%S %p")
    
    # 2. رسم الوقت في منتصف الشاشة
    time_surface = font_time.render(current_time, True, CYAN)
    time_rect = time_surface.get_rect(center=(WIDTH // 2, HEIGHT // 2))
    screen.blit(time_surface, time_rect)
    
    # 3. المبرمج ياسين بالإنجليزي (Programmer Yasin)
    en_text = font_dev.render("Programmer Yasin", True, WHITE)
    screen.blit(en_text, (50, 50))
    
    # 4. المبرمج ياسين بالصيني (程序员 雅辛)
    ch_text = font_chinese.render("程序员 雅辛", True, GOLD)
    screen.blit(ch_text, (WIDTH - 350, 50))
    
    # 5. حالة النظام
    status_text = font_dev.render("SYSTEM ACTIVE", True, GREEN)
    screen.blit(status_text, (WIDTH // 2 - 150, HEIGHT - 100))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
    pygame.display.flip()

pygame.quit()
sys.exit()
