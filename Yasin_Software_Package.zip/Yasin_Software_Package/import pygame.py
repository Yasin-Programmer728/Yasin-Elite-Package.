import pygame
import math
import sys
import os

# 1. تشغيل بايجيم
pygame.init()

# 2. إعدادات الشاشة (كبيرة وعريضة)
WIDTH, HEIGHT = 1100, 700
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Yasin Tech - Advanced Radar v2.0")

# 3. الألوان
BLACK = (10, 10, 10)
GREEN = (0, 255, 0)
DARK_GREEN = (0, 50, 0)
RED = (255, 0, 0)
WHITE = (255, 255, 255)

clock = pygame.time.Clock()
angle = 0
targets = [] 

# الخطوط
font = pygame.font.SysFont("Courier New", 25, bold=True)
title_font = pygame.font.SysFont("Courier New", 45, bold=True)

def draw_radar():
    global angle
    center = (WIDTH // 2, HEIGHT // 2 + 50)
    radius = 300
    
    # رسم الدوائر الخلفية
    for r in range(1, 5):
        pygame.draw.circle(screen, DARK_GREEN, center, (radius // 4) * r, 2)
    
    # رسم خط المسح
    x = center[0] + radius * math.cos(math.radians(angle))
    y = center[1] + radius * math.sin(math.radians(angle))
    pygame.draw.line(screen, GREEN, center, (x, y), 4)

    # فحص الأهداف
    for target in targets:
        pygame.draw.circle(screen, RED, target, 10)
        
        # حساب الزاوية بين الرادار والهدف
        target_angle = math.degrees(math.atan2(target[1] - center[1], target[0] - center[0])) % 360
        
        # لو الرادار "خبط" في الهدف
        if abs(angle - target_angle) < 3:
            pygame.draw.circle(screen, WHITE, target, 15, 2)
            # ميزة الصوت التلقائي بدون تحميل ملفات
            if os.name == 'nt': # لو ويندوز
                import winsound
                winsound.Beep(1200, 80) # صوت تردده 1200 هيرتز لمدة 80 مللي ثانية

# حلقة التشغيل
running = True
while running:
    screen.fill(BLACK)
    
    # العناوين
    title_en = title_font.render("SCANNING TERRITORY...", True, GREEN)
    title_ar = font.render("نظام الرادار المتطور - المبرمج ياسين", True, GREEN)
    screen.blit(title_en, (WIDTH // 2 - 250, 20))
    screen.blit(title_ar, (WIDTH // 2 - 180, 80))

    draw_radar()
    
    angle = (angle + 3) % 360 # سرعة الرادار

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            targets.append(event.pos) # إضافة هدف بالماوس

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
