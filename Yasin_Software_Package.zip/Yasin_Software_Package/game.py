﻿import pygame
import random
import os

pygame.init()
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption('Yasin Fire: Lone Wolf 1vs1')
font = pygame.font.SysFont('Arial', 30)

# إعدادات اللاعب (ياسين)
player_x, player_y = 400, 500
player_hp = 100
player_bullets = []

# إعدادات العدو (ذئب الوحيد)
enemy_x, enemy_y = 400, 50
enemy_hp = 100
enemy_bullets = []
enemy_direction = 1 # 1 يمين، -1 شمال

running = True
clock = pygame.time.Clock()

while running:
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT: running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            player_bullets.append([player_x + 25, player_y])

    # تحرك اللاعب
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and player_x > 0: player_x -= 7
    if keys[pygame.K_RIGHT] and player_x < 740: player_x += 7

    # تحرك العدو الذكي (بيتحرك يمين وشمال لوحده)
    enemy_x += 5 * enemy_direction
    if enemy_x <= 0 or enemy_x >= 750:
        enemy_direction *= -1
    
    # العدو بيضرب نار عشوائي
    if random.randint(1, 40) == 1:
        enemy_bullets.append([enemy_x + 25, enemy_y + 50])

    screen.fill((30, 30, 30)) # خلفية غامقة للمواجهة
    
    # رسم أشرطة الدم (HP)
    # دم اللاعب
    pygame.draw.rect(screen, (255, 0, 0), (10, 570, 200, 20))
    pygame.draw.rect(screen, (0, 255, 0), (10, 570, player_hp * 2, 20))
    # دم العدو
    pygame.draw.rect(screen, (255, 0, 0), (590, 10, 200, 20))
    pygame.draw.rect(screen, (0, 0, 255), (590, 10, enemy_hp * 2, 20))

    # رصاص اللاعب (أصفر وبيطلع لفوق)
    for pb in player_bullets[:]:
        pb[1] -= 10
        pygame.draw.rect(screen, (255, 255, 0), (pb[0], pb[1], 5, 15))
        if (enemy_x < pb[0] < enemy_x + 50) and (enemy_y < pb[1] < enemy_y + 50):
            enemy_hp -= 5
            player_bullets.remove(pb)

    # رصاص العدو (أبيض وبيلمع وبينزل لتحت)
    for eb in enemy_bullets[:]:
        eb[1] += 8
        pygame.draw.rect(screen, (255, 255, 255), (eb[0], eb[1], 5, 15))
        if (player_x < eb[0] < player_x + 50) and (player_y < eb[1] < player_y + 50):
            player_hp -= 5
            enemy_bullets.remove(eb)

    # رسم الشخصيات
    pygame.draw.rect(screen, (0, 255, 0), (player_x, player_y, 50, 50)) # أنت (أخضر)
    pygame.draw.rect(screen, (255, 0, 0), (enemy_x, enemy_y, 50, 50)) # الخصم (أحمر)

    if player_hp <= 0:
        print("Defeat! The Wolf won.")
        running = False
    if enemy_hp <= 0:
        print("Booyah! You won the 1vs1!")
        running = False
        
    pygame.display.update()
pygame.quit()
