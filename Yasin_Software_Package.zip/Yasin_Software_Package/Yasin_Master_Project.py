import pygame
import sys

# تشغيل بايجيم
pygame.init()

# ألوان البرنامج
WHITE = (255, 255, 255)
GOLD = (255, 215, 0)
BLUE = (30, 144, 255)
BLACK = (20, 20, 20) # أسود غامق فخم

# إعداد الشاشة (كبيرة وعريضة)
screen = pygame.display.set_mode((1000, 700))
pygame.display.set_caption("Yasin's Global Achievement - إنجاز ياسين العالمي")

# اختيار خط يدعم اللغات (الخط ده موجود في أغلب أجهزة ويندوز وبيدعم العربي والصيني)
font_path = "C:/Windows/Fonts/simsun.ttc" # خط Arial Unicode أو SimSum للصيني
try:
    font_big = pygame.font.Font(font_path, 60)
    font_mid = pygame.font.Font(font_path, 40)
    font_small = pygame.font.Font(font_path, 30)
except:
    # لو الخط مش موجود، هيستخدم الخط الافتراضي
    font_big = pygame.font.SysFont("Arial", 60)
    font_mid = pygame.font.SysFont("Arial", 40)
    font_small = pygame.font.SysFont("Arial", 30)

reward_amount = 0
running = True

while running:
    screen.fill(BLACK)
    
    # 1. الإنجليزية (English)
    eng_text = font_mid.render("Python Programming Master", True, WHITE)
    screen.blit(eng_text, (50, 50))

    # 2. العربية (Arabic) - لاحظ الكتابة معكوسة في بايجيم القديم فبنكتبها كدة
    # لو الخط ظهر ملخبط عندك قولي وأنا أعدلهولك بمكتبة خاصة
    ara_text = font_mid.render("محترف لغة بايثون: ياسين", True, GOLD)
    screen.blit(ara_text, (600, 150))

    # 3. الصينية (Chinese)
    # 伟大成就 (Wěidà chéngjiù) تعني "إنجاز عظيم"
    chi_text = font_mid.render("伟大成就 : Yasin", True, (0, 255, 0))
    screen.blit(chi_text, (50, 250))

    # عداد المكافأة (The Reward)
    money_label = font_big.render(f"Reward: {reward_amount} EGP", True, GOLD)
    screen.blit(money_label, (300, 400))

    # زرار المكافأة
    button_rect = pygame.Rect(350, 550, 300, 70)
    pygame.draw.rect(screen, BLUE, button_rect, border_radius=20)
    btn_text = font_small.render("GET REWARD - احصل على المكافأة", True, WHITE)
    screen.blit(btn_text, (360, 570))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            if button_rect.collidepoint(event.pos):
                reward_amount += 200 # خليها 200 عشان اللغات الكتير دي!

    pygame.display.flip()

pygame.quit()
sys.exit()
