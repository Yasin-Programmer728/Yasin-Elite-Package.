import pygame
import sys

# إعداد الألوان
WHITE = (255, 255, 255)
GOLD = (255, 215, 0)
BLUE = (30, 144, 255)
BLACK = (0, 0, 0)

# تشغيل بايجيم
pygame.init()

# إعداد شاشة كبيرة (عرض 800 في طول 600)
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("مشروع الإنجاز الكبير - ياسين")

font_big = pygame.font.SysFont("Arial", 50, bold=True)
font_small = pygame.font.SysFont("Arial", 30)

reward_amount = 0
running = True

while running:
    screen.fill(BLACK) # خلفية سوداء فخمة
    
    # نصوص العرض
    title_surface = font_big.render("Project: Python Mastermind", True, GOLD)
    name_surface = font_small.render("Developer: Yasin Mohamed", True, WHITE)
    status_surface = font_small.render("Status: Achievement Unlocked!", True, (0, 255, 0))
    
    # رسم النصوص على الشاشة
    screen.blit(title_surface, (150, 100))
    screen.blit(name_surface, (250, 200))
    screen.blit(status_surface, (230, 280))

    # رسم زرار "المكافأة"
    button_rect = pygame.Rect(300, 400, 200, 60)
    pygame.draw.rect(screen, BLUE, button_rect, border_radius=15)
    
    btn_text = font_small.render("Click for Reward", True, WHITE)
    screen.blit(btn_text, (315, 410))

    # عرض عداد الفلوس (كل ما يدوس يزيد)
    money_text = font_big.render(f"Reward: {reward_amount} EGP", True, GOLD)
    screen.blit(money_text, (230, 500))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        if event.type == pygame.MOUSEBUTTONDOWN:
            if button_rect.collidepoint(event.pos):
                reward_amount += 100 # كل ضغطة بـ 100 جنيه ;)
                print("إنجاز جديد تم تسجيله!")

    pygame.display.flip()

pygame.quit()
sys.exit()
